<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
This is the home page
</body>
</html>