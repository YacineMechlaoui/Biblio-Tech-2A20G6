<?php $this->view("admin/header",$data); ?>

<?php $this->view("admin/sidebar",$data); ?>

          		<p>Main admin page.</p>
          		

<?php $this->view("admin/footer",$data); ?>
      