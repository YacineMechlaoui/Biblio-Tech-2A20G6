<?php 

Class Payment extends Controller
{

	public function index()
	{
		
		//$User = $this->load_model('User');
 		$data = file_get_contents('php://input');
        $filename = time() .'_.txt';
        file_put_contents($filename, $data);
	}


}